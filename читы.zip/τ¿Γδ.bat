@echo off
if not "%1"=="max" start /MAX cmd /c "%~0" max & exit

color 2
:loop
echo CRITICAL ERROR: SYSTEM32 FOLDER DELETED!
goto loop
@echo off
color 2
:loop
echo CRITICAL ERROR: SYSTEM32 FOLDER DELETED!
goto loop
